# SGLang 第二次挑战

## 一、项目简介

本项目完成 SGLang 第二次挑战中的两个任务：

- **Task 1：Prefix Cache 效果实验**
- **Task 2：SGLang 请求处理流程源码追踪**

实验基于 SGLang 0.5.14，对 Prefix Cache 对推理性能的影响进行实际测量，并结合 SGLang 源码分析一次 `/generate` 请求的完整处理流程。

---

## 二、实验环境

- SGLang：0.5.14
- Ray：2.56.0
- 模型：Qwen/Qwen3-0.6B
- Python：3.12
- GPU：NVIDIA GeForce RTX 5060 Laptop GPU
- 接口：SGLang 原生 `/generate`
- 请求方式：`input_ids`
- 输出方式：Streaming

Task 1 使用：

- 测量请求数：32
- 最大并发数：8
- 输入长度：2112 Token
- 输出长度：16 Token
- `temperature=0`
- `ignore_eos=true`
- `sampling_seed=2026`

---

## 三、Task 1：Prefix Cache 实验

### 1. 共享前缀组

每个请求由：

- 2048 Token 的共享前缀
- 64 Token 的独立后缀

组成，因此每个请求总长度为 2112 Token。

正式测量前使用预热请求使共享前缀进入 Radix Cache，预热请求不计入正式的 32 个测量请求。

### 2. 分散前缀组

每个请求同样包含 2112 Token，但每个请求的第一个 Token 不同，使不同请求之间不能形成共同的 Radix Cache 前缀。

### 3. 主要实验结果

| 指标 | 共享前缀组 | 分散前缀组 |
|---|---:|---:|
| 成功率 | 100% | 100% |
| 输入长度 | 2112 | 2112 |
| 输出长度 | 16 | 16 |
| Cache Hit Rate | 96.97% | 0% |
| 实际 Prefill 总量 | 2,048 | 67,584 |
| 平均实际 Prefill / 请求 | 64 | 2,112 |
| TTFT P50 | 57.54 ms | 569.38 ms |
| TTFT P95 | 67.13 ms | 947.57 ms |
| TPOT P50 | 8.32 ms | 28.34 ms |
| E2E P50 | 183.84 ms | 992.40 ms |
| 请求吞吐 | 42.83 req/s | 7.88 req/s |
| 输出吞吐 | 685.22 tok/s | 126.07 tok/s |

实验结果表明，共享前缀可以通过 Radix Cache 复用已经计算的 KV Cache，从而减少重复 Prefill 计算。

---

## 四、Task 2：源码流程追踪

一次 `/generate` 请求的主要处理流程为：

```text
客户端 /generate
      ↓
TokenizerManager.generate_request()
      ↓
_send_one_request()
      ↓
Scheduler.event_loop_normal()
      ↓
waiting_queue
      ↓
get_new_batch_prefill()
      ↓
PrefillAdder.add_one_req()
      ↓
match_prefix_for_req()
      ↓
RadixCache.match_prefix()
      ↓
ScheduleBatch
      ↓
Scheduler.run_batch()
      ↓
TPWorker.forward_batch_generation()
      ↓
Prefill / Decode + Sampling
      ↓
update_cache_from_scheduler()
      ↓
RadixCache.cache_finished_req()
或 cache_unfinished_req()
      ↓
TokenizerManager._wait_one_response()
      ↓
Streaming 输出
```

### 关键源码文件

主要分析了以下 SGLang 0.5.14 源码：

```text
sglang/srt/managers/tokenizer_manager.py
sglang/srt/managers/scheduler.py
sglang/srt/managers/schedule_batch.py
sglang/srt/managers/tp_worker.py
sglang/srt/managers/schedule_policy.py
sglang/srt/mem_cache/radix_cache.py
```

### 关键函数

- `TokenizerManager.generate_request()`
- `TokenizerManager._send_one_request()`
- `TokenizerManager._wait_one_response()`
- `Scheduler.event_loop_normal()`
- `Scheduler.get_new_batch_prefill()`
- `Scheduler.run_batch()`
- `PrefillAdder.add_one_req()`
- `match_prefix_for_req()`
- `RadixCache.match_prefix()`
- `RadixCache.cache_finished_req()`
- `RadixCache.cache_unfinished_req()`
- `RadixCache.insert()`
- `TPWorker.forward_batch_generation()`

---

## 五、项目目录

```text
HW2/
├── README.md
├── report.pdf
├── AI 使用说明情况（第二次挑战）.pdf
├── src/
│   └── task1_experiment.py
├── target1/
│   ├── shared_prefix/
│   │   ├── request_01.json
│   │   ├── ...
│   │   ├── request_32.json
│   │   └── summary.json
│   └── dispersed_prefix/
│       ├── request_01.json
│       ├── ...
│       ├── request_32.json
│       └── summary.json
└── results/
    ├── comparison.json
    ├── shared_prefix_summary.json
    └── dispersed_prefix_summary.json
```

其中：

- `src/`：实验代码
- `target1/`：Task 1 两组 workload 的原始请求结果
- `results/`：实验汇总结果
- `report.pdf`：最终实验报告
- `AI 使用说明情况（第二次挑战）.pdf`：AI 使用情况说明

---

## 六、Task 1 实验代码

主要实验代码位于：

```text
src/task1_experiment.py
```

程序完成以下工作：

1. 构造共享前缀和分散前缀两组 workload。
2. 对模型进行预热。
3. 调用 `/flush_cache` 清理已有 Cache。
4. 分别执行两组实验。
5. 控制最大并发数为 8。
6. 使用 Streaming `/generate` 接口获取结果。
7. 记录 TTFT、TPOT、E2E、Cache Hit Rate 和 Prefill Token 等指标。
8. 保存每个请求的原始 JSON 结果。
9. 生成两组实验的 summary 和 comparison 结果。

---

## 七、结果文件说明

### shared_prefix

保存共享前缀组 32 个请求的原始结果：

```text
target1/shared_prefix/request_01.json
...
target1/shared_prefix/request_32.json
target1/shared_prefix/summary.json
```

### dispersed_prefix

保存分散前缀组 32 个请求的原始结果：

```text
target1/dispersed_prefix/request_01.json
...
target1/dispersed_prefix/request_32.json
target1/dispersed_prefix/summary.json
```

### results

保存最终汇总结果：

```text
results/comparison.json
results/shared_prefix_summary.json
results/dispersed_prefix_summary.json
```

---

## 八、说明

本项目实验结果均来自本地 SGLang 0.5.14 环境的实际运行结果。Task 2 的源码分析基于本地安装的 SGLang 0.5.14 源码完成。

