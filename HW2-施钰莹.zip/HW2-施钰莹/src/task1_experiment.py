import asyncio
import aiohttp
import json
import os
import time
import statistics
from pathlib import Path


# ============================================================
# 基本配置
# ============================================================

SERVER_URL = "http://127.0.0.1:30000"

NUM_REQUESTS = 32
MAX_CONCURRENCY = 8

PREFIX_LEN = 2048
SUFFIX_LEN = 64
TOTAL_INPUT_LEN = PREFIX_LEN + SUFFIX_LEN

MAX_NEW_TOKENS = 16
TEMPERATURE = 0
IGNORE_EOS = True
SAMPLING_SEED = 2026

BASE_DIR = Path.home() / "HW2"
RESULT_DIR = BASE_DIR / "results" / "target1"

SHARED_DIR = RESULT_DIR / "shared_prefix"
DISPERSED_DIR = RESULT_DIR / "dispersed_prefix"

SHARED_DIR.mkdir(parents=True, exist_ok=True)
DISPERSED_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 构造 token
# ============================================================

# 使用普通 token ID 构造实验输入。
# 这里主要关心 token 的数量和前缀关系，而不是自然语言语义。

# 2048 个共享前缀 token
SHARED_PREFIX = [
    30000 + (i % 1000)
    for i in range(PREFIX_LEN)
]


def make_shared_requests():
    """
    Shared Prefix:
    2048 个完全相同的前缀
    +
    每个请求不同的 64 token 后缀
    """
    requests = []

    for req_id in range(NUM_REQUESTS):

        suffix = [
            40000 + req_id * SUFFIX_LEN + j
            for j in range(SUFFIX_LEN)
        ]

        input_ids = SHARED_PREFIX + suffix

        assert len(input_ids) == TOTAL_INPUT_LEN

        requests.append(input_ids)

    return requests


def make_dispersed_requests():
    """
    Dispersed Prefix:
    总长度仍然为 2112。
    每条请求的第一个 token 不同。

    第一个 token 不同后，Radix Cache 无法从根节点开始
    复用后面的公共部分，因此不会形成 2048 token 的共享前缀。
    """
    requests = []

    for req_id in range(NUM_REQUESTS):

        # 每个请求使用不同的首 token
        first_token = 50000 + req_id

        # 后面 2047 个 token 使用相同结构
        rest = SHARED_PREFIX[1:]

        suffix = [
            40000 + req_id * SUFFIX_LEN + j
            for j in range(SUFFIX_LEN)
        ]

        # 为了保持总长度 2112：
        # 1 + 2047 + 64 = 2112
        input_ids = [first_token] + rest + suffix

        assert len(input_ids) == TOTAL_INPUT_LEN

        requests.append(input_ids)

    return requests


# ============================================================
# HTTP 请求函数
# ============================================================

async def send_generate(
    session,
    request_id,
    input_ids,
    output_dir,
    semaphore,
):
    """
    发送一次 streaming /generate 请求。
    """

    async with semaphore:

        payload = {
            "input_ids": input_ids,
            "sampling_params": {
                "temperature": TEMPERATURE,
                "max_new_tokens": MAX_NEW_TOKENS,
                "ignore_eos": IGNORE_EOS,
                "sampling_seed": SAMPLING_SEED,
            },
            "stream": True,
        }

        start_time = time.perf_counter()

        first_token_time = None
        end_time = None

        chunks = []
        final_meta = None
        all_output_ids = []

        success = False
        error_message = None

        try:
            async with session.post(
                f"{SERVER_URL}/generate",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=300),
            ) as response:

                if response.status != 200:
                    raise RuntimeError(
                        f"HTTP status = {response.status}"
                    )

                async for raw_line in response.content:

                    line = raw_line.decode(
                        "utf-8",
                        errors="replace"
                    ).strip()

                    if not line:
                        continue

                    # SSE 格式：
                    # data: {...}
                    # data: [DONE]
                    if not line.startswith("data:"):
                        continue

                    data = line[5:].strip()

                    if data == "[DONE]":
                        end_time = time.perf_counter()
                        break

                    try:
                        item = json.loads(data)
                    except json.JSONDecodeError:
                        continue

                    chunks.append(item)

                    if first_token_time is None:
                        first_token_time = time.perf_counter()

                    # 保存输出 token
                    output_ids = item.get("output_ids", [])

                    if output_ids:
                        all_output_ids = output_ids

                    # 最后一条通常包含完整 meta_info
                    meta_info = item.get("meta_info")

                    if meta_info is not None:
                        final_meta = meta_info

            if end_time is None:
                end_time = time.perf_counter()

            success = True

        except Exception as e:
            end_time = time.perf_counter()
            error_message = repr(e)

        # ====================================================
        # 计算指标
        # ====================================================

        e2e_latency = end_time - start_time

        if first_token_time is not None:
            ttft = first_token_time - start_time
        else:
            ttft = None

        completion_tokens = None
        prompt_tokens = None
        cached_tokens = 0

        if final_meta is not None:

            completion_tokens = final_meta.get(
                "completion_tokens"
            )

            prompt_tokens = final_meta.get(
                "prompt_tokens"
            )

            cached_tokens = final_meta.get(
                "cached_tokens"
            )

            if cached_tokens is None:
                cached_tokens = 0

        # 实际执行 Prefill 的 token 数
        actual_prefill_tokens = None

        if prompt_tokens is not None:
            actual_prefill_tokens = (
                prompt_tokens - cached_tokens
            )

        # TPOT
        tpot = None

        if (
            completion_tokens is not None
            and completion_tokens > 1
            and first_token_time is not None
        ):
            tpot = (
                end_time - first_token_time
            ) / (completion_tokens - 1)

        result = {
            "request_id": request_id,
            "success": success,

            "input_tokens_expected": len(input_ids),
            "prompt_tokens": prompt_tokens,

            "cached_tokens": cached_tokens,
            "actual_prefill_tokens": actual_prefill_tokens,

            "completion_tokens": completion_tokens,

            "ttft": ttft,
            "tpot": tpot,
            "e2e_latency": e2e_latency,

            "num_stream_chunks": len(chunks),

            "output_text": (
                chunks[-1].get("text", "")
                if chunks
                else ""
            ),

            "output_ids": all_output_ids,

            "error": error_message,

            "start_time": start_time,
            "end_time": end_time,

            "raw_stream": chunks,
        }

        # 保存逐请求原始结果
        output_file = output_dir / f"request_{request_id:02d}.json"

        with open(
            output_file,
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                result,
                f,
                ensure_ascii=False,
                indent=2
            )

        return result


# ============================================================
# Warm-up
# ============================================================

async def short_warmup():
    """
    首次实验前的服务预热。
    不计入正式实验。
    """

    print()
    print("=" * 70)
    print("服务预热")
    print("=" * 70)

    warmup_input = [1000, 1001, 1002, 1003]

    payload = {
        "input_ids": warmup_input,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": 16,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
        "stream": True,
    }

    async with aiohttp.ClientSession() as session:

        async with session.post(
            f"{SERVER_URL}/generate",
            json=payload,
            timeout=aiohttp.ClientTimeout(total=60),
        ) as response:

            if response.status != 200:
                raise RuntimeError(
                    f"Warm-up failed: HTTP {response.status}"
                )

            async for raw_line in response.content:

                line = raw_line.decode(
                    "utf-8",
                    errors="replace"
                ).strip()

                if line == "data: [DONE]":
                    break

    print("服务预热完成")


# ============================================================
# flush cache
# ============================================================

async def flush_cache():

    print()
    print("=" * 70)
    print("执行 /flush_cache")
    print("=" * 70)

    async with aiohttp.ClientSession() as session:

        async with session.post(
            f"{SERVER_URL}/flush_cache",
            timeout=aiohttp.ClientTimeout(total=60),
        ) as response:

            text = await response.text()

            print("HTTP status:", response.status)
            print("Server response:", text)

            if response.status != 200:
                raise RuntimeError(
                    f"flush_cache failed: HTTP {response.status}"
                )

            if "Cache flushed" not in text:
                print("警告：没有检测到 'Cache flushed.'")


# ============================================================
# Shared Prefix Warm-up
# ============================================================

async def shared_prefix_warmup():

    print()
    print("=" * 70)
    print("Shared Prefix 专用预热")
    print("=" * 70)

    # 使用完整共享前缀 + 1 个独立 token。
    # 这样主要目的是让 2048 token 共享前缀进入 Radix Cache，
    # 而不把正式测量请求的 64 token 后缀提前缓存进去。

    warmup_input = SHARED_PREFIX + [60000]

    assert len(warmup_input) == 2049

    payload = {
        "input_ids": warmup_input,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": 16,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
        "stream": True,
    }

    async with aiohttp.ClientSession() as session:

        async with session.post(
            f"{SERVER_URL}/generate",
            json=payload,
            timeout=aiohttp.ClientTimeout(total=120),
        ) as response:

            if response.status != 200:
                raise RuntimeError(
                    f"Shared warm-up failed: HTTP {response.status}"
                )

            async for raw_line in response.content:

                line = raw_line.decode(
                    "utf-8",
                    errors="replace"
                ).strip()

                if line == "data: [DONE]":
                    break

    print("Shared Prefix 预热完成")
    print("预热输入 token 数：", len(warmup_input))


# ============================================================
# 执行一组实验
# ============================================================

async def run_group(
    group_name,
    requests,
    output_dir,
):
    """

    执行一组 32 请求实验。
    最大并发 8。
    """

    print()
    print("=" * 70)
    print(f"开始实验：{group_name}")
    print("=" * 70)

    semaphore = asyncio.Semaphore(MAX_CONCURRENCY)

    connector = aiohttp.TCPConnector(
        limit=MAX_CONCURRENCY
    )

    group_start = time.perf_counter()

    async with aiohttp.ClientSession(
        connector=connector
    ) as session:

        tasks = []

        for i, input_ids in enumerate(requests):

            task = asyncio.create_task(
                send_generate(
                    session=session,
                    request_id=i + 1,
                    input_ids=input_ids,
                    output_dir=output_dir,
                    semaphore=semaphore,
                )
            )

            tasks.append(task)

        results = await asyncio.gather(*tasks)

    group_end = time.perf_counter()

    total_wall_time = group_end - group_start

    return results, total_wall_time


# ============================================================
# 百分位
# ============================================================

def percentile(values, p):

    values = [
        x for x in values
        if x is not None
    ]

    if not values:
        return None

    values = sorted(values)

    index = (len(values) - 1) * p / 100

    lower = int(index)
    upper = min(lower + 1, len(values) - 1)

    weight = index - lower

    return (
        values[lower] * (1 - weight)
        + values[upper] * weight
    )


# ============================================================
# 汇总统计
# ============================================================

def summarize(
    group_name,
    results,
    total_wall_time,
):

    successful = [
        r for r in results
        if r["success"]
    ]

    success_rate = (
        len(successful) / len(results)
        if results
        else 0
    )

    ttft_values = [
        r["ttft"]
        for r in successful
        if r["ttft"] is not None
    ]

    tpot_values = [
        r["tpot"]
        for r in successful
        if r["tpot"] is not None
    ]

    e2e_values = [
        r["e2e_latency"]
        for r in successful
        if r["e2e_latency"] is not None
    ]

    cached_values = [
        r["cached_tokens"]
        for r in successful
        if r["cached_tokens"] is not None
    ]

    prefill_values = [
        r["actual_prefill_tokens"]
        for r in successful
        if r["actual_prefill_tokens"] is not None
    ]

    output_tokens = sum(
        r["completion_tokens"] or 0
        for r in successful
    )

    input_tokens = sum(
        r["prompt_tokens"] or 0
        for r in successful
    )

    cached_tokens = sum(
        r["cached_tokens"] or 0
        for r in successful
    )

    actual_prefill = sum(
        r["actual_prefill_tokens"] or 0
        for r in successful
    )

    # 缓存命中率：
    # 总 cached tokens / 总 prompt tokens
    cache_hit_rate = (
        cached_tokens / input_tokens
        if input_tokens > 0
        else 0
    )

    # 输出吞吐量：output tokens / 整组墙钟时间
    output_throughput = (
        output_tokens / total_wall_time
        if total_wall_time > 0
        else 0
    )

    # 请求吞吐量
    request_throughput = (
        len(successful) / total_wall_time
        if total_wall_time > 0
        else 0
    )

    summary = {
        "group": group_name,

        "total_requests": len(results),
        "successful_requests": len(successful),

        "success_rate": success_rate,

        "total_wall_time": total_wall_time,

        "request_throughput_req_per_sec":
            request_throughput,

        "output_throughput_tokens_per_sec":
            output_throughput,

        "total_prompt_tokens":
            input_tokens,

        "total_cached_tokens":
            cached_tokens,

        "total_actual_prefill_tokens":
            actual_prefill,

        "cache_hit_rate":
            cache_hit_rate,

        "ttft_p50":
            percentile(ttft_values, 50),

        "ttft_p95":
            percentile(ttft_values, 95),

        "tpot_p50":
            percentile(tpot_values, 50),

        "tpot_p95":
            percentile(tpot_values, 95),

        "e2e_p50":
            percentile(e2e_values, 50),

        "e2e_p95":
            percentile(e2e_values, 95),

        "avg_cached_tokens":
            statistics.mean(cached_values)
            if cached_values
            else None,

        "avg_actual_prefill_tokens":
            statistics.mean(prefill_values)
            if prefill_values
            else None,
    }

    return summary


# ============================================================
# 保存汇总
# ============================================================

def save_summary(summary, output_dir):

    output_file = output_dir / "summary.json"

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            ensure_ascii=False,
            indent=2
        )

    print()
    print("汇总结果：")

    for key, value in summary.items():
        print(f"{key}: {value}")

    print()
    print("汇总文件：", output_file)


# ============================================================
# 主程序
# ============================================================

async def main():

    print("=" * 70)
    print("SGLang Task 1 - Prefix Cache Experiment")
    print("=" * 70)

    print()
    print("实验配置：")
    print("测量请求数：", NUM_REQUESTS)
    print("最大并发：", MAX_CONCURRENCY)
    print("共享前缀：", PREFIX_LEN)
    print("独立后缀：", SUFFIX_LEN)
    print("输入总长度：", TOTAL_INPUT_LEN)
    print("max_new_tokens：", MAX_NEW_TOKENS)
    print("temperature：", TEMPERATURE)
    print("sampling_seed：", SAMPLING_SEED)

    # --------------------------------------------------------
    # 构造两组输入
    # --------------------------------------------------------

    shared_requests = make_shared_requests()
    dispersed_requests = make_dispersed_requests()

    print()
    print("输入检查：")

    print(
        "Shared:",
        len(shared_requests),
        "requests ×",
        len(shared_requests[0]),
        "tokens"
    )

    print(
        "Dispersed:",
        len(dispersed_requests),
        "requests ×",
        len(dispersed_requests[0]),
        "tokens"
    )

    assert len(shared_requests) == 32
    assert len(dispersed_requests) == 32

    assert all(
        len(x) == 2112
        for x in shared_requests
    )

    assert all(
        len(x) == 2112
        for x in dispersed_requests
    )

    assert len(
        {x[0] for x in dispersed_requests}
    ) == 32

    # --------------------------------------------------------
    # 第一次服务预热
    # --------------------------------------------------------

    await short_warmup()

    # --------------------------------------------------------
    # Shared Prefix 实验
    # --------------------------------------------------------

    # 先清缓存
    await flush_cache()

    # 再进行 Shared Prefix 专用预热
    await shared_prefix_warmup()

    # 正式测量 32 请求
    shared_results, shared_wall_time = await run_group(
        "shared_prefix",
        shared_requests,
        SHARED_DIR,
    )

    shared_summary = summarize(
        "shared_prefix",
        shared_results,
        shared_wall_time,
    )

    save_summary(
        shared_summary,
        SHARED_DIR,
    )

    # --------------------------------------------------------
    # Dispersed Prefix 实验
    # --------------------------------------------------------

    # 两组实验之间必须重新清空缓存
    await flush_cache()

    # 不进行前缀预热
    dispersed_results, dispersed_wall_time = await run_group(
        "dispersed_prefix",
        dispersed_requests,
        DISPERSED_DIR,
    )

    dispersed_summary = summarize(
        "dispersed_prefix",
        dispersed_results,
        dispersed_wall_time,
    )

    save_summary(
        dispersed_summary,
        DISPERSED_DIR,
    )

    # --------------------------------------------------------
    # 最终比较
    # --------------------------------------------------------

    comparison = {
        "shared_prefix": shared_summary,
        "dispersed_prefix": dispersed_summary,
    }

    comparison_file = RESULT_DIR / "comparison.json"

    with open(
        comparison_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            comparison,
            f,
            ensure_ascii=False,
            indent=2
        )

    print()
    print("=" * 70)
    print("实验全部完成")
    print("=" * 70)

    print("Shared Prefix:")
    print(
        "  Cache hit rate:",
        shared_summary["cache_hit_rate"]
    )
    print(
        "  Actual Prefill:",
        shared_summary["total_actual_prefill_tokens"]
    )
    print(
        "  TTFT p50:",
        shared_summary["ttft_p50"]
    )
    print(
        "  E2E p50:",
        shared_summary["e2e_p50"]
    )

    print()
    print("Dispersed Prefix:")
    print(
        "  Cache hit rate:",
        dispersed_summary["cache_hit_rate"]
    )
    print(
        "  Actual Prefill:",
        dispersed_summary["total_actual_prefill_tokens"]
    )
    print(
        "  TTFT p50:",
        dispersed_summary["ttft_p50"]
    )
    print(
        "  E2E p50:",
        dispersed_summary["e2e_p50"]
    )

    print()
    print("比较结果：")
    print(comparison_file)


if __name__ == "__main__":
    asyncio.run(main())
